package com.masterme4a.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.TextComponent;

public final class Masterme4aMenuScreen extends Screen {
    private static final int PURPLE = 0xFFB45CFF;
    private static final int PANEL = 0xE6191028;
    private static final int MUTED = 0xFFB9A9C9;

    public Masterme4aMenuScreen() {
        super(new TextComponent("Masterme4a M4"));
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int top = this.height / 2 - 65;
        int buttonWidth = 220;
        int left = center - buttonWidth / 2;

        addToggle(left, top, "FPS", ClientConfig.SHOW_FPS.get(), () ->
                ClientConfig.SHOW_FPS.set(!ClientConfig.SHOW_FPS.get()));
        addToggle(left, top + 25, "Координаты XYZ", ClientConfig.SHOW_COORDINATES.get(), () ->
                ClientConfig.SHOW_COORDINATES.set(!ClientConfig.SHOW_COORDINATES.get()));
        addToggle(left, top + 50, "Направление взгляда", ClientConfig.SHOW_DIRECTION.get(), () ->
                ClientConfig.SHOW_DIRECTION.set(!ClientConfig.SHOW_DIRECTION.get()));
        addToggle(left, top + 75, "Мини-карта", ClientConfig.SHOW_MINIMAP.get(), () ->
                ClientConfig.SHOW_MINIMAP.set(!ClientConfig.SHOW_MINIMAP.get()));
        addToggle(left, top + 100, "Радар существ", ClientConfig.SHOW_ENTITY_RADAR.get(), () ->
                ClientConfig.SHOW_ENTITY_RADAR.set(!ClientConfig.SHOW_ENTITY_RADAR.get()));
        addToggle(left, top + 125, "Радар сундуков", ClientConfig.SHOW_CHEST_RADAR.get(), () ->
                ClientConfig.SHOW_CHEST_RADAR.set(!ClientConfig.SHOW_CHEST_RADAR.get()));

        addRenderableWidget(new Button(left, top + 158, buttonWidth, 20,
                new TextComponent("Друзья"), button -> this.minecraft.setScreen(new FriendsScreen(this)),
                (button, pose, mouseX, mouseY) -> {}));
        addRenderableWidget(new Button(left, top + 183, buttonWidth, 20,
                new TextComponent("Закрыть"), button -> onClose(),
                (button, pose, mouseX, mouseY) -> {}));
    }

    private void addToggle(int x, int y, String name, boolean enabled, Runnable toggle) {
        String label = name + ": " + (enabled ? "ВКЛ" : "ВЫКЛ");
        addRenderableWidget(new Button(x, y, 220, 20, new TextComponent(label), button -> {
            toggle.run();
            button.setMessage(new TextComponent(name + ": " +
                    (isEnabled(name) ? "ВКЛ" : "ВЫКЛ")));
        }, (button, pose, mouseX, mouseY) -> {}));
    }

    private boolean isEnabled(String name) {
        if ("FPS".equals(name)) return ClientConfig.SHOW_FPS.get();
        if ("Координаты XYZ".equals(name)) return ClientConfig.SHOW_COORDINATES.get();
        if ("Направление взгляда".equals(name)) return ClientConfig.SHOW_DIRECTION.get();
        if ("Мини-карта".equals(name)) return ClientConfig.SHOW_MINIMAP.get();
        if ("Радар существ".equals(name)) return ClientConfig.SHOW_ENTITY_RADAR.get();
        if ("Радар сундуков".equals(name)) return ClientConfig.SHOW_CHEST_RADAR.get();
        return false;
    }

    @Override
    public void render(PoseStack pose, int mouseX, int mouseY, float partialTick) {
        renderBackground(pose);
        int panelWidth = 270;
        int panelHeight = 275;
        int left = (this.width - panelWidth) / 2;
        int top = (this.height - panelHeight) / 2 - 2;
        GuiComponent.fill(pose, left, top, left + panelWidth, top + panelHeight, PANEL);
        GuiComponent.fill(pose, left, top, left + panelWidth, top + 3, PURPLE);
        String title = "MASTERME4A M4";
        this.font.draw(pose, title, this.width / 2.0F - this.font.width(title) / 2.0F,
                top + 13, PURPLE);
        String subtitle = "K — открыть / закрыть";
        this.font.draw(pose, subtitle, this.width / 2.0F - this.font.width(subtitle) / 2.0F,
                top + 30, MUTED);
        super.render(pose, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
