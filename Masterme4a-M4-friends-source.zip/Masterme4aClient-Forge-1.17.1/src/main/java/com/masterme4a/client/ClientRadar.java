package com.masterme4a.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.EnderChestBlock;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = "masterme4a", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientRadar {
    private static final int SIZE = 104;
    private static final int RANGE = 32;
    private static final List<BlockPos> CHESTS = new ArrayList<>();
    private static int refreshFrames = 0;

    private ClientRadar() {}

    @SubscribeEvent
    public static void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL || !ClientConfig.SHOW_MINIMAP.get()) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.options.hideGui) return;
        PoseStack pose = event.getMatrixStack();
        int x = mc.getWindow().getGuiScaledWidth() - SIZE - 10;
        int y = 10;
        GuiComponent.fill(pose, x - 3, y - 3, x + SIZE + 3, y + SIZE + 3, 0xD9160D24);
        GuiComponent.fill(pose, x - 3, y - 3, x + SIZE + 3, y, 0xFFB45CFF);
        GuiComponent.fill(pose, x - 3, y + SIZE, x + SIZE + 3, y + SIZE + 3, 0xFFB45CFF);
        GuiComponent.fill(pose, x - 3, y, x, y + SIZE, 0xFFB45CFF);
        GuiComponent.fill(pose, x + SIZE, y, x + SIZE + 3, y + SIZE, 0xFFB45CFF);
        GuiComponent.fill(pose, x, y, x + SIZE, y + SIZE, 0xA51A1424);

        int cx = x + SIZE / 2;
        int cy = y + SIZE / 2;
        // Crosshair and player marker
        GuiComponent.fill(pose, cx - 1, y + 5, cx + 1, y + SIZE - 5, 0x55FFFFFF);
        GuiComponent.fill(pose, x + 5, cy - 1, x + SIZE - 5, cy + 1, 0x55FFFFFF);
        GuiComponent.fill(pose, cx - 3, cy - 3, cx + 4, cy + 4, 0xFFFFD85C);

        if (++refreshFrames >= 20) {
            refreshFrames = 0;
            refreshChests(player);
        }
        if (ClientConfig.SHOW_CHEST_RADAR.get()) {
            for (BlockPos pos : CHESTS) {
                drawMarker(pose, cx, cy, player, pos.getX() + 0.5, pos.getZ() + 0.5, 0xFF35D7FF);
            }
        }
        if (ClientConfig.SHOW_ENTITY_RADAR.get()) {
            for (Entity entity : mc.level.entitiesForRendering()) {
                if (entity == player || entity.isRemoved()) continue;
                if (!(entity instanceof LivingEntity) && !(entity instanceof ItemEntity)) continue;
                double distance = player.distanceToSqr(entity);
                if (distance > RANGE * RANGE) continue;
                int color = entity instanceof Player ?
                        (FriendManager.isFriend(entity.getName().getString()) ? 0xFFB45CFF : 0xFFFF5555) :
                        entity instanceof ItemEntity ? 0xFFFFD85C : 0xFF70E080;
                drawMarker(pose, cx, cy, player, entity.getX(), entity.getZ(), color);
            }
        }
        mc.font.draw(pose, "M4", x + 4, y + 4, 0xFFB45CFF);
    }

    private static void refreshChests(LocalPlayer player) {
        CHESTS.clear();
        BlockPos origin = player.blockPosition();
        for (int dx = -RANGE; dx <= RANGE; dx++) {
            for (int dz = -RANGE; dz <= RANGE; dz++) {
                if (dx * dx + dz * dz > RANGE * RANGE) continue;
                for (int dy = -4; dy <= 4; dy++) {
                    BlockPos pos = origin.offset(dx, dy, dz);
                    Block block = player.level.getBlockState(pos).getBlock();
                    if (block instanceof ChestBlock || block instanceof EnderChestBlock || block instanceof BarrelBlock) {
                        CHESTS.add(pos.immutable());
                    }
                }
            }
        }
    }

    private static void drawMarker(PoseStack pose, int cx, int cy, LocalPlayer player,
                                   double worldX, double worldZ, int color) {
        double dx = worldX - player.getX();
        double dz = worldZ - player.getZ();
        double yaw = Math.toRadians(player.yRot);
        double rx = dx * Math.cos(yaw) - dz * Math.sin(yaw);
        double rz = dx * Math.sin(yaw) + dz * Math.cos(yaw);
        double scale = (SIZE / 2.0 - 7) / RANGE;
        int sx = cx + (int) Math.round(rx * scale);
        int sy = cy + (int) Math.round(rz * scale);
        if (sx < cx - SIZE / 2 + 3 || sx > cx + SIZE / 2 - 3 || sy < cy - SIZE / 2 + 3 || sy > cy + SIZE / 2 - 3) return;
        GuiComponent.fill(pose, sx - 2, sy - 2, sx + 3, sy + 3, color);
    }
}
