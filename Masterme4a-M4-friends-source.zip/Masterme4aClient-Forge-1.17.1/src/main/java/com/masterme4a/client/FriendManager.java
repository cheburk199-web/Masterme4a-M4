package com.masterme4a.client;

import net.minecraft.client.Minecraft;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Local client-side friend list, stored in config/masterme4a-friends.txt. */
public final class FriendManager {
    private static final List<String> FRIENDS = new ArrayList<>();
    private static boolean loaded = false;
    private FriendManager() {}

    private static Path file() { return Minecraft.getInstance().gameDirectory.toPath().resolve("config").resolve("masterme4a-friends.txt"); }
    private static void load() {
        if (loaded) return;
        loaded = true;
        try {
            Path path = file();
            if (Files.exists(path)) for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
                String name = line.trim();
                if (valid(name) && !contains(name)) FRIENDS.add(name);
            }
        } catch (IOException ignored) { }
    }
    private static boolean valid(String name) { return name != null && name.matches("[A-Za-z0-9_]{1,16}"); }
    private static boolean contains(String name) {
        for (String friend : FRIENDS) if (friend.equalsIgnoreCase(name)) return true;
        return false;
    }
    private static void save() {
        try {
            Path path = file();
            Files.createDirectories(path.getParent());
            Files.write(path, FRIENDS, StandardCharsets.UTF_8);
        } catch (IOException ignored) { }
    }
    public static boolean add(String name) {
        load(); name = name == null ? "" : name.trim();
        if (!valid(name) || contains(name)) return false;
        FRIENDS.add(name); save(); return true;
    }
    public static boolean remove(String name) {
        load();
        for (int i = 0; i < FRIENDS.size(); i++) if (FRIENDS.get(i).equalsIgnoreCase(name)) { FRIENDS.remove(i); save(); return true; }
        return false;
    }
    public static boolean isFriend(String name) { load(); return name != null && contains(name); }
    public static List<String> all() { load(); return Collections.unmodifiableList(new ArrayList<>(FRIENDS)); }
}
