package com.masterme4a.client;

import net.minecraftforge.common.ForgeConfigSpec;

public final class ClientConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.BooleanValue SHOW_FPS;
    public static final ForgeConfigSpec.BooleanValue SHOW_COORDINATES;
    public static final ForgeConfigSpec.BooleanValue SHOW_DIRECTION;
    public static final ForgeConfigSpec.IntValue BACKGROUND_OPACITY;
    public static final ForgeConfigSpec.BooleanValue SHOW_MINIMAP;
    public static final ForgeConfigSpec.BooleanValue SHOW_ENTITY_RADAR;
    public static final ForgeConfigSpec.BooleanValue SHOW_CHEST_RADAR;
    public static final ForgeConfigSpec SPEC;

    static {
        BUILDER.push("hud");
        SHOW_FPS = BUILDER.comment("Show frames per second").define("showFps", true);
        SHOW_COORDINATES = BUILDER.comment("Show player coordinates").define("showCoordinates", true);
        SHOW_DIRECTION = BUILDER.comment("Show facing direction").define("showDirection", true);
        BACKGROUND_OPACITY = BUILDER.comment("HUD background opacity (0-255)")
                .defineInRange("backgroundOpacity", 120, 0, 255);
        SHOW_MINIMAP = BUILDER.comment("Show the minimap overlay").define("showMinimap", true);
        SHOW_ENTITY_RADAR = BUILDER.comment("Show nearby living entities on minimap").define("showEntityRadar", true);
        SHOW_CHEST_RADAR = BUILDER.comment("Show nearby chests, ender chests and barrels on minimap").define("showChestRadar", true);
        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    private ClientConfig() {}
}
