package com.masterme4a.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.TextComponent;
import java.util.List;

public final class FriendsScreen extends Screen {
    private final Screen parent;
    private EditBox nameField;
    public FriendsScreen(Screen parent) { super(new TextComponent("Друзья — Masterme4a M4")); this.parent = parent; }

    @Override protected void init() {
        int left = this.width / 2 - 120;
        nameField = new EditBox(this.font, left, 48, 240, 20, new TextComponent("Ник игрока"));
        nameField.setMaxLength(16); nameField.setHint(new TextComponent("Ник игрока"));
        addRenderableWidget(nameField);
        addRenderableWidget(new Button(left, 74, 240, 20, new TextComponent("Добавить в друзья"), b -> {
            if (FriendManager.add(nameField.getValue())) { nameField.setValue(""); rebuildWidgets(); }
        }));
        List<String> friends = FriendManager.all();
        int shown = Math.min(friends.size(), 8);
        for (int i = 0; i < shown; i++) {
            final String friend = friends.get(i);
            addRenderableWidget(new Button(left, 104 + i * 23, 240, 20, new TextComponent("Удалить: " + friend), b -> {
                FriendManager.remove(friend); rebuildWidgets();
            }));
        }
        addRenderableWidget(new Button(left, 104 + shown * 23 + 5, 240, 20, new TextComponent("Назад"), b -> onClose()));
    }

    @Override public void render(PoseStack pose, int mouseX, int mouseY, float partialTick) {
        renderBackground(pose);
        String title = "ДРУЗЬЯ: " + FriendManager.all().size();
        this.font.draw(pose, title, this.width / 2f - this.font.width(title) / 2f, 25, 0xFFB45CFF);
        this.font.draw(pose, "Фиолетовая метка на радаре — друг", this.width / 2f - 100, 280, 0xFFB9A9C9);
        super.render(pose, mouseX, mouseY, partialTick);
    }
    @Override public void onClose() { this.minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
