# Masterme4a M4 — Forge 1.17.1

A visual-only Minecraft HUD mod. It does not add cheats, combat automation, or gameplay advantages.

## Build

Requires JDK 16 and Gradle 7.3.3.

```bash
gradle --no-daemon build
```

The mod JAR is created in `build/libs/`.

## HUD

Displays the Masterme4a label, FPS, player coordinates, and facing direction. HUD options are stored in the Forge client config.

## Управление меню

В игре нажмите **Right Shift** (правый Shift), чтобы открыть или закрыть меню Masterme4a. В меню можно включать и выключать FPS, координаты XYZ и направление взгляда.


M4 overlay: purple HUD, K key menu, nearby entity radar (players/mobs/items) and nearby chest/ender chest/barrel markers. Radar only displays objects in currently loaded client-side chunks and does not reveal unloaded terrain.
